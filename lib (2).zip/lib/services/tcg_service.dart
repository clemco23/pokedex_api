// import 'dart:convert';
// import 'package:http/http.dart' as http;
// import '../models/pokemon_card.dart';

// class TcgService {
//   final String baseUrl = "https://api.pokemontcg.io/v2/cards";
  
//   // Clé API Pokémon TCG
//   final String apiKey = "3afa160f-3c42-4a66-a973-c06dbf467bdc"; 

//   // Headers pour les requêtes
//   Map<String, String> get _headers => {
//     "X-Api-Key": apiKey,
//     "Content-Type": "application/json",
//   };

//   // Récupérer les cartes avec pagination (Explore)
//   Future<List<PokemonCard>> fetchCards({int page = 1, int pageSize = 20}) async {
//     try {
//       final response = await http.get(
//         Uri.parse('$baseUrl?page=$page&pageSize=$pageSize'),
//         headers: _headers,
//       );

//       if (response.statusCode == 200) {
//         final data = json.decode(response.body);
//         final List cards = data['data'] ?? [];
//         return cards.map((json) => PokemonCard.fromJson(json)).toList();
//       } else if (response.statusCode == 403) {
//         throw Exception('Clé API invalide ou manquante');
//       } else if (response.statusCode == 429) {
//         throw Exception('Limite de requêtes atteinte. Veuillez réessayer plus tard.');
//       } else {
//         throw Exception('Erreur ${response.statusCode}: Impossible de charger les cartes');
//       }
//     } catch (e) {
//       if (e.toString().contains('SocketException')) {
//         throw Exception('Pas de connexion Internet');
//       }
//       rethrow;
//     }
//   }

//   // Rechercher une carte par nom (Search)
//   Future<List<PokemonCard>> searchCards(String query) async {
//     if (query.trim().isEmpty) {
//       return [];
//     }

//     try {
//       final response = await http.get(
//         Uri.parse('$baseUrl?q=name:$query*'),
//         headers: _headers,
//       );

//       if (response.statusCode == 200) {
//         final data = json.decode(response.body);
//         final List cards = data['data'] ?? [];
//         return cards.map((json) => PokemonCard.fromJson(json)).toList();
//       } else if (response.statusCode == 403) {
//         throw Exception('Clé API invalide');
//       } else {
//         throw Exception('Erreur de recherche');
//       }
//     } catch (e) {
//       if (e.toString().contains('SocketException')) {
//         throw Exception('Pas de connexion Internet');
//       }
//       rethrow;
//     }
//   }

//   // Récupérer une carte par ID (Detail)
//   Future<PokemonCard> fetchCardById(String id) async {
//     try {
//       final response = await http.get(
//         Uri.parse('$baseUrl/$id'),
//         headers: _headers,
//       );

//       if (response.statusCode == 200) {
//         final data = json.decode(response.body);
//         return PokemonCard.fromJson(data['data']);
//       } else {
//         throw Exception('Carte non trouvée');
//       }
//     } catch (e) {
//       rethrow;
//     }
//   }
// }

import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/pokemon_card.dart';

class TcgService {
  final String baseUrl = "https://api.tcgdex.net/v2/en";
  
  // TCGdex ne nécessite pas de clé API
  Map<String, String> get _headers => {
    "Content-Type": "application/json",
  };

  // Récupérer les cartes avec pagination (Explore)
  Future<List<PokemonCard>> fetchCards({int page = 1, int pageSize = 20}) async {
    try {
      // TCGdex utilise des sets/séries, on va récupérer des cartes d'une série populaire
      // Pour paginer, on va récupérer plusieurs séries ou cartes
      final response = await http.get(
        Uri.parse('$baseUrl/cards'),
        headers: _headers,
      );

      if (response.statusCode == 200) {
        final List<dynamic> cards = json.decode(response.body);
        
        // Pagination manuelle car TCGdex retourne toutes les cartes
        final startIndex = (page - 1) * pageSize;
        final endIndex = startIndex + pageSize;
        
        final paginatedCards = cards.sublist(
          startIndex.clamp(0, cards.length),
          endIndex.clamp(0, cards.length),
        );
        
        // Récupérer les détails complets de chaque carte
        final detailedCards = await Future.wait(
          paginatedCards.map((card) => fetchCardById(card['id'])).toList(),
        );
        
        return detailedCards;
      } else {
        throw Exception('Erreur ${response.statusCode}: Impossible de charger les cartes');
      }
    } catch (e) {
      if (e.toString().contains('SocketException')) {
        throw Exception('Pas de connexion Internet');
      }
      rethrow;
    }
  }

  // Rechercher une carte par nom (Search)
  Future<List<PokemonCard>> searchCards(String query) async {
    if (query.trim().isEmpty) {
      return [];
    }

    try {
      // Récupérer toutes les cartes et filtrer localement
      final response = await http.get(
        Uri.parse('$baseUrl/cards'),
        headers: _headers,
      );

      if (response.statusCode == 200) {
        final List<dynamic> allCards = json.decode(response.body);
        
        // Filtrer les cartes par nom
        final filteredCards = allCards.where((card) {
          final name = card['name']?.toString().toLowerCase() ?? '';
          return name.contains(query.toLowerCase());
        }).take(20).toList(); // Limiter à 20 résultats
        
        // Récupérer les détails complets
        if (filteredCards.isEmpty) {
          return [];
        }
        
        final detailedCards = await Future.wait(
          filteredCards.map((card) => fetchCardById(card['id'])).toList(),
        );
        
        return detailedCards;
      } else {
        throw Exception('Erreur de recherche');
      }
    } catch (e) {
      if (e.toString().contains('SocketException')) {
        throw Exception('Pas de connexion Internet');
      }
      rethrow;
    }
  }

  // Récupérer une carte par ID (Detail)
  Future<PokemonCard> fetchCardById(String id) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/cards/$id'),
        headers: _headers,
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return PokemonCard.fromJson(data);
      } else {
        throw Exception('Carte non trouvée');
      }
    } catch (e) {
      rethrow;
    }
  }

  // Méthode alternative : récupérer les cartes d'un set spécifique
  Future<List<PokemonCard>> fetchCardsFromSet(String setId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/sets/$setId'),
        headers: _headers,
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final List<dynamic> cards = data['cards'] ?? [];
        
        return cards.map((json) => PokemonCard.fromJson(json)).toList();
      } else {
        throw Exception('Impossible de charger les cartes du set');
      }
    } catch (e) {
      rethrow;
    }
  }

  // Récupérer la liste des sets disponibles
  Future<List<Map<String, dynamic>>> fetchSets() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/sets'),
        headers: _headers,
      );

      if (response.statusCode == 200) {
        final List<dynamic> sets = json.decode(response.body);
        return sets.cast<Map<String, dynamic>>();
      } else {
        throw Exception('Impossible de charger les sets');
      }
    } catch (e) {
      rethrow;
    }
  }
}

