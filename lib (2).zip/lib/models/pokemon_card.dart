// class PokemonCard {
//   final String id;
//   final String name;
//   final String imageUrl;
//   final String largeImageUrl;
//   final String hp;
//   final List<String> types;
//   final String rarity;
//   final String? artist;
//   final List<Attack> attacks;

//   PokemonCard({
//     required this.id,
//     required this.name,
//     required this.imageUrl,
//     required this.largeImageUrl,
//     required this.hp,
//     required this.types,
//     required this.rarity,
//     this.artist,
//     this.attacks = const [],
//   });

//   factory PokemonCard.fromJson(Map<String, dynamic> json) {
//     // Extraction sécurisée des images
//     String smallImage = '';
//     String largeImage = '';
    
//     if (json['images'] != null) {
//       smallImage = json['images']['small'] ?? '';
//       largeImage = json['images']['large'] ?? '';
//     }

//     // Extraction des types
//     List<String> cardTypes = [];
//     if (json['types'] != null && json['types'] is List) {
//       cardTypes = (json['types'] as List<dynamic>)
//           .map((e) => e.toString())
//           .toList();
//     }

//     // Extraction des attaques
//     List<Attack> cardAttacks = [];
//     if (json['attacks'] != null && json['attacks'] is List) {
//       cardAttacks = (json['attacks'] as List<dynamic>)
//           .map((e) => Attack.fromJson(e))
//           .toList();
//     }

//     return PokemonCard(
//       id: json['id'] ?? '',
//       name: json['name'] ?? 'Unknown',
//       imageUrl: smallImage,
//       largeImageUrl: largeImage,
//       hp: json['hp'] ?? 'N/A',
//       types: cardTypes,
//       rarity: json['rarity'] ?? 'Common',
//       artist: json['artist'],
//       attacks: cardAttacks,
//     );
//   }
// }

// class Attack {
//   final String name;
//   final String damage;
//   final List<String> cost;
//   final String text;

//   Attack({
//     required this.name,
//     required this.damage,
//     required this.cost,
//     required this.text,
//   });

//   factory Attack.fromJson(Map<String, dynamic> json) {
//     List<String> energyCost = [];
//     if (json['cost'] != null && json['cost'] is List) {
//       energyCost = (json['cost'] as List<dynamic>)
//           .map((e) => e.toString())
//           .toList();
//     }

//     return Attack(
//       name: json['name'] ?? '',
//       damage: json['damage'] ?? '',
//       cost: energyCost,
//       text: json['text'] ?? '',
//     );
//   }
// }
class PokemonCard {
  final String id;
  final String name;
  final String imageUrl;
  final String largeImageUrl;
  final String hp;
  final List<String> types;
  final String rarity;
  final String? artist;
  final List<Attack> attacks;
  final String? setName;
  final String? number;

  PokemonCard({
    required this.id,
    required this.name,
    required this.imageUrl,
    required this.largeImageUrl,
    required this.hp,
    required this.types,
    required this.rarity,
    this.artist,
    this.attacks = const [],
    this.setName,
    this.number,
  });

  factory PokemonCard.fromJson(Map<String, dynamic> json) {
    // Extraction des images selon la structure TCGdex
    String smallImage = '';
    String largeImage = '';
    
    if (json['image'] != null) {
      // TCGdex a une structure différente pour les images
      if (json['image'] is String) {
        smallImage = json['image'];
        largeImage = json['image'];
      } else if (json['image'] is Map) {
        smallImage = json['image']['small'] ?? json['image']['thumb'] ?? '';
        largeImage = json['image']['large'] ?? json['image']['high'] ?? smallImage;
      }
    }

    // Extraction des types
    List<String> cardTypes = [];
    if (json['types'] != null && json['types'] is List) {
      cardTypes = (json['types'] as List<dynamic>)
          .map((e) => e.toString())
          .toList();
    }

    // Extraction des attaques (structure TCGdex)
    List<Attack> cardAttacks = [];
    if (json['attacks'] != null && json['attacks'] is List) {
      cardAttacks = (json['attacks'] as List<dynamic>)
          .map((e) => Attack.fromJson(e))
          .toList();
    }

    // Extraction de la rareté
    String cardRarity = 'Common';
    if (json['rarity'] != null) {
      if (json['rarity'] is String) {
        cardRarity = json['rarity'];
      } else if (json['rarity'] is Map && json['rarity']['name'] != null) {
        cardRarity = json['rarity']['name'];
      }
    }

    // Extraction du HP
    String cardHp = 'N/A';
    if (json['hp'] != null) {
      cardHp = json['hp'].toString();
    }

    // Extraction du set
    String? setName;
    if (json['set'] != null) {
      if (json['set'] is String) {
        setName = json['set'];
      } else if (json['set'] is Map && json['set']['name'] != null) {
        setName = json['set']['name'];
      }
    }

    return PokemonCard(
      id: json['id'] ?? '',
      name: json['name'] ?? 'Unknown',
      imageUrl: smallImage,
      largeImageUrl: largeImage,
      hp: cardHp,
      types: cardTypes,
      rarity: cardRarity,
      artist: json['illustrator'] ?? json['artist'], // TCGdex utilise "illustrator"
      attacks: cardAttacks,
      setName: setName,
      number: json['localId'] ?? json['dexId']?.toString(),
    );
  }
}

class Attack {
  final String name;
  final String damage;
  final List<String> cost;
  final String text;

  Attack({
    required this.name,
    required this.damage,
    required this.cost,
    required this.text,
  });

  factory Attack.fromJson(Map<String, dynamic> json) {
    List<String> energyCost = [];
    if (json['cost'] != null && json['cost'] is List) {
      energyCost = (json['cost'] as List<dynamic>)
          .map((e) => e.toString())
          .toList();
    }

    // TCGdex peut avoir la structure de dégâts différente
    String damageValue = '';
    if (json['damage'] != null) {
      if (json['damage'] is String) {
        damageValue = json['damage'];
      } else if (json['damage'] is int) {
        damageValue = json['damage'].toString();
      }
    }

    // TCGdex utilise "effect" au lieu de "text"
    String effectText = json['effect'] ?? json['text'] ?? '';

    return Attack(
      name: json['name'] ?? '',
      damage: damageValue,
      cost: energyCost,
      text: effectText,
    );
  }
}
